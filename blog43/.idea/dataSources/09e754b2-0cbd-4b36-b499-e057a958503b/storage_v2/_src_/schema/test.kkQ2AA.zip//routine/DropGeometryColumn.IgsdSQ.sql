CREATE PROCEDURE DropGeometryColumn(IN catalog         VARCHAR(64), IN t_schema VARCHAR(64), IN t_name VARCHAR(64),
                                    IN geometry_column VARCHAR(64))
  begin
  set @qwe= concat('ALTER TABLE ', t_schema, '.', t_name, ' DROP ', geometry_column); PREPARE ls from @qwe; execute ls; deallocate prepare ls; end;

